const ratings = document.querySelectorAll(".rating");
const submitBtn = document.getElementById("submit-btn");
const ratingCard = document.querySelector(".rating-card");
const thankYouCard = document.querySelector(".thank-you-card");
const selectedRating = document.getElementById("selected-rating");

let selectedValue = null;

ratings.forEach(rating => {
    rating.addEventListener("click", () => {
        ratings.forEach(r => r.classList.remove("selected"));
        rating.classList.add("selected");
        selectedValue = rating.textContent;
    });
});

submitBtn.addEventListener("click", () => {
    if (selectedValue) {
        ratingCard.classList.add("hidden");
        thankYouCard.classList.remove("hidden");
        selectedRating.textContent = selectedValue;
    } else {
        alert("Please select a rating before submitting.");
    }
});